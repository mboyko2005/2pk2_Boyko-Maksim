﻿using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows;

//Для получения информации об этой сборке используются следующие общие атрибуты. 
//Вы можете изменить значения этих атрибутов, чтобы изменить информацию, связанную со сборкой.
[assembly: AssemblyTitle("pz_26")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("pz_26")]
[assembly: AssemblyCopyright("Copyright ©  2023")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

//Если значение параметра ComVisible установлено на False, то типы, определенные в этой сборке, становятся невидимыми для компонентов COM.
//Если вам нужно обращаться к типу в этой сборке из модели COM, необходимо установить атрибут ComVisible для этого типа в значение True. 
//Установка значения False для параметра ComVisible делает типы в этой сборке невидимыми для компонентов COM.
//Если необходимо обратиться к типу в этой сборке через из модели COM, установите атрибут ComVisible для этого типа в значение True.
[assembly: ComVisible(false)]

//Для начала создания локализуемых приложений в файле .csproj внутри секции <PropertyGroup> необходимо задать параметр <UICulture>CultureYouAreCodingWith</UICulture>.
//Например, если вы используете английский (США) в своих исходных файлах, установите значение <UICulture> в en-US.
//Затем необходимо раскомментировать атрибут NeutralResourceLanguage, указав соответствующую культуру внутри скобок.
//В данном случае, строка должна выглядеть следующим образом:
//[assembly: NeutralResourcesLanguage("en-US", UltimateResourceFallbackLocation.Satellite)]


[assembly: ThemeInfo(
    ResourceDictionaryLocation.None, 
    //Словари ресурсов по конкретным тематикам расположены в свойстве
	ResourceDictionaryLocation.SourceAssembly //Если ресурс не найден на странице или в словарях ресурсов приложения, то поиск осуществляется в словарях ресурсов, связанных с конкретной темой.
//Если ресурс не найден и там, то используется словарь универсальных ресурсов, расположенный также в свойстве
)]


// Сведения о версии для сборки включают четыре следующих значения:
//Основной номер версии
//Дополнительный номер версии
//Номер сборки
//Номер редакции
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
